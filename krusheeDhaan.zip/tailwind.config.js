/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./public/*.ejs"],
  theme: {
    extend: {},
  },
  plugins: [],
}

